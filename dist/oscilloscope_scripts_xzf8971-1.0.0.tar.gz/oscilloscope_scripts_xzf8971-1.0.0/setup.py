from setuptools import setup
from setuptools import find_packages



setup(
    packages=find_packages(),
    zip_safe=False,
)
