from . import QuickAnalysis
